% Created by Chantal Tax, August 2024, modified by Erick Canales-Rodríguez
% to create the Waveforms required by the MC simulator of Jonathan Patino.

clear all; close all;

format long

gamma = 42.57747892*2*pi; % [MHz/T] = 10^6 [1/s T] = [1/ms mT] (note: 42.57747892 is the value of gamma divided by 2pi)
t90   = 2;%0.6; % [ms]
t180  = 4;%1.2; % [ms]
%tri   = 1.1; % readout time until echo[ms]
tri   = 1.0; % readout time until echo[ms]
%tri   = 0; % readout time until echo[ms] ---for a spiral

% Connectome 1.0
% G     = 265e-6; % mT/m = e-6 mT/um ----> connetome 1.0
% S     = 83e-6; % 200 T/m/s = 200e3 mT/m/s = 200e-3 mT/um/s = 200e-6 mT/um/ms ----> connetome 1.0

% Connectome 2.0
G     = 500e-6; % mT/m = e-6 mT/um  ----> connetome 2.0
S     = 600e-6; % 200 T/m/s = 200e3 mT/m/s = 200e-3 mT/um/s = 200e-6 mT/um/ms
%S     = 1e20; % Infinite slow rate (rectangular pulse)

tr    = G/S;

if tri >= 0.5*t90
    tau1 = tri;
    tau2 = tri-0.5*t90;
    minTE = t180+4*tr+2*tri;
else
    tau1 = 0.5*t90;
    tau2 = tau1;
    minTE = t90+t180+4*tr;
end

syms TE % has to be in ms
delta = TE/2 - t180/2 - tau1 - G/S;
delta_ = matlabFunction(delta);

Delta = delta + tr + t180 + tau2;
Delta_ = matlabFunction(Delta);
b = vpa(gamma^2 * G^2 * (delta.^2.*(Delta-delta/3)+ (tr^3)/30 - (delta*tr^2)/6)); % max b-value as function of TE
b_ = matlabFunction(b);
coeff = fliplr(double(coeffs(b,TE)));

%TEs = minTE:0.001:50; bs = b_(TEs);
TEs = linspace(minTE, 20, 5000); bs = b_(TEs);
deltas = delta_(TEs);
Deltas = Delta_(TEs);

figure
plot(TEs,bs)
xlabel('TE [ms]');
ylabel('b-value');

%figure;
bs_eval = bs(1:end);
[value08, ind08]    = min((bs - 0.8).^2);
[value1, ind1]      = min((bs - 1.0).^2);
[value15, ind15]    = min((bs - 1.5).^2);
[value20, ind20]    = min((bs - 2.0).^2);
[value25, ind25]    = min((bs - 2.5).^2);
[value30, ind30]    = min((bs - 3.0).^2);

indices = [ind08, ind1, ind15, ind20, ind25, ind30];

bvalues_ind = zeros(length(indices),1);
Deltas_ind  = zeros(length(indices),1);
deltas_ind  = zeros(length(indices),1);
E_ind       = zeros(length(indices),1); 

figure('units','normalized','outerposition',[0 0 0.525 1.0]);

%t = tiledlayout(3, 2, "TileSpacing", "tight");
t = tiledlayout(3, 2, "TileSpacing", "compact");

%Grid_t = linspace(0, 20, 1000); % in ms
temporal_res  = 1000;
Time_duration = 20 * 10^-3; % s
Grid_t = linspace(0, Time_duration, temporal_res); % in s

% load matrix of gradient directions
grad_dir = load('directions.txt');
[fil, col] = size(grad_dir);

Waveform_G  = zeros(length(indices), temporal_res);

for i=1:length(indices)
    %subplot(3,2,i)
    nexttile
    wf_n = indices(i);% pick acquisition setting number
    wf_t = [0 0.5*t90 0.5*t90+tr 0.5*t90+deltas(wf_n) 0.5*t90+tr+deltas(wf_n) ...
        0.5*t90+Deltas(wf_n) 0.5*t90+Deltas(wf_n)+tr 0.5*t90+Deltas(wf_n)+deltas(wf_n) ...
        0.5*t90+Deltas(wf_n)+tr+deltas(wf_n) 0.5*t90+Deltas(wf_n)+tr+deltas(wf_n)+tri];
    
    wf = [0 0 G G 0 0 -G -G 0 0];
    %wf = [0 0 G G 0 0 G G 0 0];

    rfrd_t = [0 0.5*t90 0.5*t90 TEs(wf_n)/2-0.5*t180 TEs(wf_n)/2-0.5*t180 TEs(wf_n)/2+0.5*t180 TEs(wf_n)/2+0.5*t180 ...
        TEs(wf_n)-tri TEs(wf_n)-tri TEs(wf_n) TEs(wf_n)];
    rf = [G/10 G/10 0 0 G/10 G/10 0 0 0 0 0];
    rd = [0 0 0 0 0 0 0 0 G/10 G/10 0];
    
    % conversion from micrometer to meter
    wf = wf*10^6;
    rf = rf*10^6;
    rd = rd*10^6;
    
    % conversion from militesla to tesla
    wf = wf*10^-3;
    rf = rf*10^-3;
    rd = rd*10^-3;
    
    % Time Conversion from ms to s
    wf_t = wf_t     * 10^-3;
    rfrd_t = rfrd_t * 10^-3;
    
    plot(wf_t,wf, 'LineWidth',2.0); 
    hold on;
    plot(rfrd_t,rf, 'LineWidth',1.5);
    plot(rfrd_t,rd, 'LineWidth',1.5); 
    if (i == 5) | (i==6)
        xlabel('time [s]');
    end
    if (i == 1) | (i==3) | (i==5)
        ylabel('G [T/m]');
    end

    round_factor = 3;
    title(['$TE = ' num2str(round(TEs(wf_n),round_factor)) ' \  ms, \ b = ' num2str(round(bs(wf_n),round_factor)) ' \  ms/\mu m^2,  \  \Delta=' num2str(round(Deltas(wf_n),round_factor)) ' \  ms,  \  \delta=' num2str(round(deltas(wf_n),round_factor)) ' \  ms$'], 'interpreter', 'latex', 'fontsize', 11.5)
    xlim([0, Time_duration])
    set(gca,'linewidth', 1)
    display(['b-value = ' num2str(bs(wf_n))  '; Delta = ' num2str(Deltas(wf_n)) '; delta = ' num2str(deltas(wf_n))]);
    
    bvalues_ind(i) = bs(wf_n);
    Deltas_ind(i)  = Deltas(wf_n);
    deltas_ind(i)  = deltas(wf_n);
    E_ind(i)       = tr;
    
    %------interpolate Gradients
    Waveform_G(i,:) = interp1(wf_t, wf, Grid_t, 'linear','extrap');
    plot(Grid_t, Waveform_G(i,:), '--r', 'LineWidth',1.0);
end
f = gcf;
print(f,['Diffusion_protocol2_tri_' num2str(tri) '.png'],'-dpng','-r600');
exportgraphics(f,['Diffusion_protocol_tri_' num2str(tri) '.pdf'],'ContentType','vector', 'Resolution',600)
exportgraphics(f,['Diffusion_protocol_tri_' num2str(tri) '.png'],'Resolution',600)

save('bvalues.txt','bvalues_ind','-ascii')
save('Deltas.txt','Deltas_ind','-ascii')
save('deltas.txt','deltas_ind','-ascii')
save('ramp_time.txt','E_ind','-ascii')

Matrix_wavefor_design      = zeros(temporal_res * fil * length(indices) + 1,col);
Matrix_wavefor_design(1,:) = [Time_duration, temporal_res, fil * length(indices)]; 

cont = 1;
for j = 1:fil % directions
    dir_j = grad_dir(j,:);
    for i=1:length(indices) % protocol (waveform type)
        Waveform_G_i = Waveform_G(i,:);
        for k = 1:length(Waveform_G_i) % temporal profile
            cont = cont + 1;
            Matrix_wavefor_design(cont,:) = dir_j * Waveform_G_i(k);
        end
    end
end

save('Matrix_wavefor_design_full.txt','Matrix_wavefor_design','-ascii')

b_val_vector     = zeros(fil * length(indices),1);
Delta_vector     = zeros(fil * length(indices),1);
delta_vector     = zeros(fil * length(indices),1);
E_vector         = zeros(fil * length(indices),1);

cont = 0;
for j = 1:fil % directions
    dir_j = grad_dir(j,:);
    for i=1:length(indices) % protocol (waveform type)
        cont = cont + 1;
        b_val_vector(cont) = bvalues_ind(i) * sqrt(sum(dir_j.^2));
        Delta_vector(cont) = Deltas_ind(i);
        delta_vector(cont) = deltas_ind(i);
        E_vector(cont)     = E_ind(i);
    end
end

save('b_val_vector.txt','b_val_vector','-ascii')
save('Delta_vector.txt','Delta_vector','-ascii')
save('delta_vector.txt','delta_vector','-ascii')
save('ramp_vector.txt','E_vector','-ascii')

% ------------------------------------------------------------------------%
% Reduced protocol with only the first shell
Matrix_wavefor_design_red      = zeros(temporal_res * fil + 1,col);
Matrix_wavefor_design_red(1,:) = [Time_duration, temporal_res, fil]; 
cont = 1;
for j = 1:fil % directions
    dir_j = grad_dir(j,:);
    Waveform_G_b1500 = Waveform_G(3,:);
    for k = 1:length(Waveform_G_b1500) % temporal profile
        cont = cont + 1;
        Matrix_wavefor_design_red(cont,:) = dir_j * Waveform_G_b1500(k);
    end
end

save('Matrix_wavefor_design_b1500.txt','Matrix_wavefor_design_red','-ascii')
