% Created by Chantal Tax, August 2024

clear all; close all;

gamma = 42.57747892*2*pi; % [MHz/T] = 10^6 [1/s T] = [1/ms mT]
t90   = 2;%0.6; % [ms]
t180  = 4;%1.2; % [ms]
%tri   = 1.1; % readout time until echo[ms]
tri   = 1.0; % readout time until echo[ms]
%tri   = 0; % readout time until echo[ms] ---for a spiral

% Connectome 1.0
% G     = 265e-6; % mT/m = e-6 mT/um ----> connetome 1.0
% S     = 83e-6; % 200 T/m/s = 200e3 mT/m/s = 200e-3 mT/um/s = 200e-6 mT/um/ms ----> connetome 1.0

% Connectome 2.0
G     = 500e-6; % mT/m = e-6 mT/um  ----> connetome 2.0
%S     = 600e-6; % 200 T/m/s = 200e3 mT/m/s = 200e-3 mT/um/s = 200e-6 mT/um/ms
S     = 1e20; % Infinite slow rate (rectangular pulse)


tr    = G/S;

if tri >= 0.5*t90
    tau1 = tri;
    tau2 = tri-0.5*t90;
    minTE = t180+4*tr+2*tri;
else
    tau1 = 0.5*t90;
    tau2 = tau1;
    minTE = t90+t180+4*tr;
end

syms TE % has to be in ms
delta = TE/2 - t180/2 - tau1 - G/S;
delta_ = matlabFunction(delta);

Delta = delta + tr + t180 + tau2;
Delta_ = matlabFunction(Delta);
b = vpa(gamma^2 * G^2 * (delta.^2.*(Delta-delta/3)+ (tr^3)/30 - (delta*tr^2)/6)); % max b-value as function of TE
b_ = matlabFunction(b);
coeff = fliplr(double(coeffs(b,TE)));

TEs = minTE:0.001:50; bs = b_(TEs);
deltas = delta_(TEs);
Deltas = Delta_(TEs);

figure
plot(TEs,bs)
xlabel('TE [ms]');
ylabel('b-value');


%figure;
bs_eval = bs(1:end);
[value08, ind08]    = min((bs - 0.8).^2);
[value1, ind1]      = min((bs - 1.0).^2);
[value15, ind15]    = min((bs - 1.5).^2);
[value20, ind20]    = min((bs - 2.0).^2);
[value25, ind25]    = min((bs - 2.5).^2);
[value30, ind30]    = min((bs - 3.0).^2);

indices = [ind08, ind1, ind15, ind20, ind25, ind30];

figure('units','normalized','outerposition',[0 0 0.525 1.0]);

%t = tiledlayout(3, 2, "TileSpacing", "tight");
t = tiledlayout(3, 2, "TileSpacing", "compact");


for i=1:length(indices)
    %subplot(3,2,i)
    nexttile
    wf_n = indices(i);% pick acquisition setting number
    wf_t = [0 0.5*t90 0.5*t90+tr 0.5*t90+deltas(wf_n) 0.5*t90+tr+deltas(wf_n) ...
        0.5*t90+Deltas(wf_n) 0.5*t90+Deltas(wf_n)+tr 0.5*t90+Deltas(wf_n)+deltas(wf_n) ...
        0.5*t90+Deltas(wf_n)+tr+deltas(wf_n) 0.5*t90+Deltas(wf_n)+tr+deltas(wf_n)+tri];
    
    wf = [0 0 G G 0 0 G G 0 0];
    rfrd_t = [0 0.5*t90 0.5*t90 TEs(wf_n)/2-0.5*t180 TEs(wf_n)/2-0.5*t180 TEs(wf_n)/2+0.5*t180 TEs(wf_n)/2+0.5*t180 ...
        TEs(wf_n)-tri TEs(wf_n)-tri TEs(wf_n) TEs(wf_n)];
    rf = [G/10 G/10 0 0 G/10 G/10 0 0 0 0 0];
    rd = [0 0 0 0 0 0 0 0 G/10 G/10 0];
    
    % conversion from micrometer to meter
    wf = wf*10^6;
    rf = rf*10^6;
    rd = rd*10^6;
    
    plot(wf_t,wf, 'LineWidth',2.0); 
    hold on;
    plot(rfrd_t,rf, 'LineWidth',1.5);
    plot(rfrd_t,rd, 'LineWidth',1.5); 
    if (i == 5) | (i==6)
        xlabel('time [ms]');
    end
    if (i == 1) | (i==3) | (i==5)
        %ylabel('G [mT/\mu m]');
        ylabel('G [mT/m]');
    end

    round_factor = 3;
    title(['$TE = ' num2str(round(TEs(wf_n),round_factor)) ' \  ms, \ b = ' num2str(round(bs(wf_n),round_factor)) ' \  ms/\mu m^2,  \  \Delta=' num2str(round(Deltas(wf_n),round_factor)) ' \  ms,  \  \delta=' num2str(round(deltas(wf_n),round_factor)) ' \  ms$'], 'interpreter', 'latex', 'fontsize', 11.5)
    xlim([0, 27])
    set(gca,'linewidth', 1)
    display(['b-value = ' num2str(bs(wf_n))  '; Delta = ' num2str(Deltas(wf_n)) '; delta = ' num2str(deltas(wf_n))]);
end
f = gcf;
print(f,['Diffusion_protocol2_tri_' num2str(tri) '.png'],'-dpng','-r600');
exportgraphics(f,['Diffusion_protocol_tri_' num2str(tri) '.pdf'],'ContentType','vector', 'Resolution',600)
exportgraphics(f,['Diffusion_protocol_tri_' num2str(tri) '.png'],'Resolution',600)
